d3.dsv(",","q3.csv", (d)=>{
    return {
        year: new Date(+d.year, 0),
        running_total: parseInt(d.running_total)
    }
    }).then((dataset) =>{ 
        // console.log(dataset)
        var w = 1000
        var h = 500
        var p = 1
        var padding = 50
        var x_max = d3.max(dataset, (d) => {return d.year}) // TODO: parse data and return years here
        var x_min = d3.min(dataset, (d) => {return d.year})
        var y_max = d3.max(dataset, (d) => {return d.running_total}) // TODO: parse data and return cumulative legosets
        // // console.log ("x_max is: " + x_max)
        // console.log ("y_max is: " + y_max)
        var x_scale = d3.scaleTime().domain([x_min, x_max]).range([padding, w-padding]) //TODO: change to Time scale and parse incoming data
        var y_scale = d3.scaleLinear().domain([y_max,0]).range([padding, h-padding])
        var h_scale = d3.scaleLinear().domain([0, y_max]).range([padding, h-padding])
        var x_ticks = []
        for (var i =x_min; i < x_max; i+=3){ // TODO: change dataset to length of years
            x_ticks.push(i)
        }
        // console.log(x_ticks)
        var y_ticks = []
        for (var i =0; i < y_max; i+=500){ //
            y_ticks.push(i)
        }

        // console.log(y_ticks)
        var x_axis = d3.axisBottom(x_scale).ticks(d3.timeYear.every(3));
        var y_axis = d3.axisLeft(y_scale).tickValues(y_ticks);
        var svg = d3.select("body").append("svg").attr("width", w).attr("height", h)
        svg.selectAll("rect").data(dataset).enter().append("rect")
        .attr("x", (d,i)=>{return (padding+(i*((w-2*padding)/dataset.length)))}).attr("y", (d)=>{ 
             return ((h)-(h_scale(d.running_total)))}).attr("width", (((w-(2*padding))/dataset.length) - p)).attr("height", (d)=>{ return h_scale(d.running_total)-(padding);})
        .attr("fill", "teal")
        svg.append("g").attr("class", "axis").attr("transform", "translate(0," + (h - padding)+ ")").call(x_axis)
        svg.append("g").attr("class", "axis").attr("transform", "translate(" + padding+ ",0)").call(y_axis)
        svg.append("g").append('text').attr('class', 'title').attr('y', padding/2).attr('x', 400).text("Rebrickable Lego Sets by Year");
        svg.append("g").append('text').attr('class', 'title').attr('y', h-10).attr('x', w-(100+padding)).text("aeissa3").style("font-size", "12px");
            }).catch((error)=> {console.log(error)
        })
